const { env } = require('node:process');

// creating USER_NAME :
process.env.USER_NAME = 'RAVI';
console.log(`hello!! ${process.env.USER_NAME}`);


//getting USERNAME of the system owner :
let USERNAME = process.env.USERNAME
console.log(`the current USERNAME is : ${USERNAME}`);

console.log(env);