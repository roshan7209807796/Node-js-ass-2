const fs = require("fs");
const path = "./readLine.txt";
const readLine = require("readline").createInterface({
  input: fs.createReadStream(path),
});

readLine.on("line", function (input) {
  console.log(`Hello!! ${input}`);
});
